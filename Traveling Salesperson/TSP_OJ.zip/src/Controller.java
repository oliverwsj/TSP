import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Controller {

	public static void main(String[] args) {
		GUIBox myGUI = new GUIBox();
	}

}
